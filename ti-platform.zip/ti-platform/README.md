# Threat Intelligence Aggregation Platform

Müxtəlif açıq/pulsuz Threat Intelligence (TI) mənbələrindən avtomatik data toplayıb, normallaşdırıb, vahid verilənlər bazasında saxlayan və real-time dashboard-da göstərən platforma. Kibertəhlükəsizlik kursunun final layihəsi üçün hazırlanmışdır.

## Nə edir?

- Arxa planda (scheduler) müəyyən aralıqlarla bir neçə TI mənbəsinə sorğu göndərir
- Hər mənbədən gələn müxtəlif formatdakı datanı **vahid IOC (Indicator of Compromise) modelinə** çevirir
- Dublikatları aradan qaldırır, mövcud IOC-ları yeniləyir
- SQLite bazasında saxlayır
- REST API vasitəsilə statistika və axtarış imkanı verir
- Tək səhifəlik dashboard-da qrafiklər, KPI-lar və filtrlənə bilən cədvəl göstərir

## İnteqrasiya olunmuş mənbələr

| Mənbə | Nə verir | API açarı | Qeydiyyat |
|---|---|---|---|
| **AbuseIPDB** | Zərərli fəaliyyət bildirilmiş IP-lər | Lazımdır (pulsuz) | https://www.abuseipdb.com/register |
| **URLhaus** (abuse.ch) | Zərərli proqram yayan URL-lər | İstəyə bağlı* | https://auth.abuse.ch/ |
| **ThreatFox** (abuse.ch) | C2 server IP/domain/hash IOC-ları | Lazımdır (pulsuz) | https://auth.abuse.ch/ |
| **AlienVault OTX** | İcma tərəfindən paylaşılan IOC-lar | Lazımdır (pulsuz) | https://otx.alienvault.com |
| **NVD** (NIST) | Son CVE / zəiflik məlumatları | Lazım deyil (key rate-limiti artırır) | https://nvd.nist.gov/developers/request-an-api-key |

\* URLhaus üçün Auth-Key olmasa, tətbiq avtomatik olaraq abuse.ch-ın ictimai bulk JSON feed-inə keçir (real-time deyil, amma işləyir).

Yeni mənbə əlavə etmək çox asandır — bax: **"Yeni mənbə necə əlavə olunur"** bölməsinə.

## Arxitektura

```
                     ┌─────────────────────┐
                     │   APScheduler        │  hər N dəqiqədən bir
                     │  (background job)     │──────────┐
                     └─────────────────────┘           │
                                                          ▼
┌──────────┐   ┌──────────┐   ┌───────────┐   ┌─────────────────┐
│AbuseIPDB │   │ URLhaus  │   │ ThreatFox │   │  Collectors       │
│   API    │──▶│   API    │──▶│    API    │──▶│ (normalizasiya)   │
└──────────┘   └──────────┘   └───────────┘   └────────┬─────────┘
   OTX API ─────────────────────────────────────────────┤
   NVD API ─────────────────────────────────────────────┘
                                                          ▼
                                              ┌─────────────────────┐
                                              │   SQLite (IOC table) │
                                              └──────────┬───────────┘
                                                          ▼
                                              ┌─────────────────────┐
                                              │   FastAPI REST API   │
                                              │  /api/iocs /api/stats│
                                              └──────────┬───────────┘
                                                          ▼
                                              ┌─────────────────────┐
                                              │  Dashboard (HTML/JS)  │
                                              │  Chart.js qrafiklər   │
                                              └─────────────────────┘
```

**Texnologiyalar:** Python 3.11, FastAPI, SQLAlchemy, SQLite, APScheduler, vanilla JS + Chart.js (heç bir frontend framework tələb olunmur).

## Quraşdırma

### Variant A — birbaşa Python ilə

```bash
cd ti-platform
python3 -m venv venv
source venv/bin/activate          # Windows-da: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# .env faylını açıb heç olmasa bir mənbənin API açarını daxil edin
# (ən asanı: AbuseIPDB, ya da heç nə etmədən NVD + URLhaus fallback ilə də işə düşür)

uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Sonra brauzerdə: **http://localhost:8000**

### Variant B — Docker ilə

```bash
cd ti-platform
cp .env.example .env
# .env-i doldurun
docker compose up --build
```

## API açarlarını necə əldə etmək olar (hamısı pulsuzdur)

1. **AbuseIPDB** — https://www.abuseipdb.com/register saytında qeydiyyatdan keçin → e-poçtu təsdiqləyin → **Account → API** bölməsindən "Create Key" düyməsi ilə açar yaradın.
2. **abuse.ch (URLhaus / ThreatFox)** — https://auth.abuse.ch/ saytına Google/GitHub/Microsoft hesabı ilə daxil olun → profil səhifəsində "Auth-Key" görünəcək, kopyalayın.
3. **AlienVault OTX** — https://otx.alienvault.com saytında qeydiyyatdan keçin → **Settings → API Integration** bölməsindən açarı kopyalayın.
4. **NVD** — açar olmadan da işləyir, amma https://nvd.nist.gov/developers/request-an-api-key ünvanından pulsuz açar alıb rate-limiti artıra bilərsiniz.

Açarları `.env` faylına yapışdırın və serveri yenidən başladın.

## API endpoint-ləri

| Endpoint | Metod | Təsvir |
|---|---|---|
| `/api/health` | GET | Server statusu |
| `/api/sources` | GET | Mövcud mənbələr və hansının aktiv olduğu |
| `/api/iocs` | GET | IOC siyahısı (filtrlər: `source`, `ioc_type`, `severity`, `q`, `limit`, `offset`) |
| `/api/iocs/{id}` | GET | Bir IOC-un tam detalı (orijinal API cavabı ilə) |
| `/api/stats` | GET | Dashboard üçün ümumi statistika |
| `/api/fetch-logs` | GET | Son collector işə düşmələrinin tarixçəsi |
| `/api/refresh` | POST | Bütün mənbələri dərhal yenilə (arxa planda) |
| `/api/refresh/{source}` | POST | Yalnız bir mənbəni yenilə |

Tam interaktiv API sənədləşdirməsi: **http://localhost:8000/docs** (FastAPI avtomatik Swagger UI yaradır).

## Verilənlər bazası modeli

Bütün mənbələrdən gələn data `IOC` cədvəlində vahid formata salınır:

- `ioc_type` — ip / url / domain / hash / cve / other
- `value` — IOC-un özü
- `source` — hansı mənbədən gəldiyi
- `threat_type` — malware, phishing, botnet, vulnerability və s.
- `confidence` — 0-100 arası güvən balı
- `severity` — low / medium / high / critical
- `tags`, `country`, `description`, `raw_json`
- `first_seen`, `last_seen`, `created_at`

`FetchLog` cədvəli isə hər collector işə düşəndə nəticəni (uğur/xəta, neçə qeyd, neçəsi yeni) qeyd edir.

## Yeni mənbə necə əlavə olunur

1. `app/collectors/` qovluğunda yeni fayl yaradın (məs. `yeni_menbe.py`)
2. İçində `fetch(db: Session) -> dict` funksiyası yazın, nümunə üçün `app/collectors/abuseipdb.py`-a baxın
3. `app.collectors.base.upsert_ioc()` funksiyasını çağıraraq datanı vahid formata salıb bazaya yazın
4. `app/collectors/__init__.py` faylındakı `COLLECTORS` lüğətinə əlavə edin
5. Lazım olsa `app/config.py`-a yeni API açarı üçün sətir əlavə edin

Bu qədər — scheduler və dashboard avtomatik olaraq yeni mənbəni tanıyacaq.

## Kurs təqdimatı üçün qeydlər

Bu layihə aşağıdakı konsepsiyaları praktik şəkildə göstərir:
- **Threat Intelligence aggregation** — müxtəlif formatdakı feed-lərin normallaşdırılması (STIX/TAXII konsepsiyasının sadələşdirilmiş versiyası)
- **IOC lifecycle** — first_seen/last_seen ilə IOC-ların "yaşamasını" izləmək
- **Deduplication** — eyni IOC müxtəlif mənbələrdən gələndə təkrarlanmır
- **Automation** — scheduler ilə insan müdaxiləsi olmadan davamlı data yığılması
- **Actionable dashboard** — SOC analitikinin real vaxtda görəcəyi tərzdə vizuallaşdırma

Təqdimatda göstərmək üçün: `/api/refresh` düyməsini basıb canlı olaraq yeni IOC-ların bazaya düşməsini və dashboard-un yenilənməsini nümayiş etdirə bilərsiniz.
