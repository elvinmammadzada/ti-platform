"""
Demo/nümayiş məlumatları yaradan skript.
Real API açarları hazır olmayanda dashboard-u boş görməmək üçün istifadə olunur.
İşə salmaq: python -m scripts.seed_demo_data  (layihənin kök qovluğundan)
"""
import json
import random
from datetime import datetime, timedelta

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import init_db, SessionLocal, IOC, FetchLog

SOURCES = ["abuseipdb", "urlhaus", "threatfox", "otx", "nvd"]
SEVERITIES = ["low", "medium", "high", "critical"]
THREAT_TYPES = ["malware", "phishing", "botnet_c2", "ransomware", "trojan", "scanner", "vulnerability"]

SAMPLE_IPS = list({f"185.220.{random.randint(1,254)}.{random.randint(1,254)}" for _ in range(80)})
SAMPLE_DOMAINS = list({
    f"malicious-{w}{random.randint(1,999)}.example-tld{random.randint(1,20)}.com"
    for w in ["update", "secure-login", "cdn-static", "billing-portal", "verify-account", "auth", "mail"]
    for _ in range(8)
})
SAMPLE_URLS = [f"http://{d}/payload{random.randint(1000,99999)}.exe" for d in SAMPLE_DOMAINS]
SAMPLE_HASHES = [f"{random.getrandbits(256):064x}" for _ in range(80)]
SAMPLE_CVES = list({f"CVE-2025-{random.randint(10000,49999)}" for _ in range(60)})


def random_value(ioc_type):
    return {
        "ip": random.choice(SAMPLE_IPS),
        "domain": random.choice(SAMPLE_DOMAINS),
        "url": random.choice(SAMPLE_URLS),
        "hash": random.choice(SAMPLE_HASHES),
        "cve": random.choice(SAMPLE_CVES),
    }[ioc_type]


def seed():
    init_db()
    db = SessionLocal()

    existing = db.query(IOC).count()
    if existing > 0:
        print(f"Bazada artıq {existing} qeyd var. Demo data yenidən əlavə edilmir.")
        return

    ioc_types = ["ip", "domain", "url", "hash", "cve"]
    now = datetime.utcnow()
    seen_combos = set()

    i = 0
    attempts = 0
    while i < 180 and attempts < 2000:
        attempts += 1
        ioc_type = random.choice(ioc_types)
        source = random.choice(SOURCES)
        value = random_value(ioc_type)
        combo = (ioc_type, value, source)
        if combo in seen_combos:
            continue
        seen_combos.add(combo)

        days_ago = random.randint(0, 7)
        seen = now - timedelta(days=days_ago, hours=random.randint(0, 23))
        severity = random.choices(SEVERITIES, weights=[30, 35, 25, 10])[0]
        confidence = {"low": 30, "medium": 55, "high": 78, "critical": 95}[severity] + random.randint(-10, 10)

        ioc = IOC(
            ioc_type=ioc_type,
            value=value,
            source=source,
            threat_type=random.choice(THREAT_TYPES),
            confidence=max(0, min(100, confidence)),
            severity=severity,
            tags=",".join(random.sample(["c2", "exploit-kit", "spam", "apt", "commodity"], k=2)),
            country=random.choice(["US", "RU", "CN", "NL", "DE", "BR", "IR", ""]),
            description=f"Demo qeyd - {source} mənbəsindən nümunə IOC",
            raw_json=json.dumps({"demo": True}),
            first_seen=seen,
            last_seen=seen,
            created_at=seen,
        )
        db.add(ioc)
        i += 1

    db.commit()

    for source in SOURCES:
        db.add(FetchLog(
            source=source,
            status="success",
            message="Demo seed",
            fetched_count=random.randint(20, 60),
            new_count=random.randint(5, 20),
            started_at=now - timedelta(minutes=random.randint(1, 120)),
            finished_at=now - timedelta(minutes=random.randint(0, 1)),
        ))
    db.commit()
    db.close()
    print("180 demo IOC uğurla əlavə edildi.")


if __name__ == "__main__":
    seed()
