"""
AI Assistant modulu (Google Gemini).

Dashboard-dakı IOC datası üzərində sual-cavab imkanı verir: istifadəçi təbii dildə
sual verir ("son 24 saatda ən çox rast gəlinən təhdid növü nədir?", "bu IP təhlükəlidirmi: 1.2.3.4"
və s.), biz bazadan qısa bir kontekst çıxarıb Gemini-yə göndəririk və cavabı qaytarırıq.
"""
import json
import logging
import time
from datetime import datetime, timedelta

import requests
from sqlalchemy import func, desc
from sqlalchemy.orm import Session

from app.config import settings
from app.database import IOC

logger = logging.getLogger("ti-platform.assistant")

# Google tez-tez model adlarını dəyişir, ona görə əvvəlcə API-dən mövcud modellərin siyahısını
# alırıq (ListModels), tapılmasa aşağıdakı statik siyahıya düşürük.
GEMINI_FALLBACK_MODELS = [
    "gemini-3.8-flash", "gemini-3.8-flash-lite", "gemini-flash-latest",
    "gemini-flash-lite-latest", "gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-pro-latest",
]
_model_cache: dict = {"models": None, "ts": 0.0}


def _gemini_url(model: str) -> str:
    return f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

SYSTEM_PROMPT = """Sən "SentryFeed" adlı Threat Intelligence Aggregation Platformasının daxili AI köməkçisisən.
Platforma AbuseIPDB, URLhaus, ThreatFox, AlienVault OTX və NVD kimi açıq mənbələrdən IOC (Indicator of
Compromise) toplayır: IP-lər, domenlər, URL-lər, hash-lər və CVE-lər.

Sənə hər sualla birlikdə bazadan çıxarılmış qısa JSON statistika/kontekst veriləcək. Bu konteksti
əsas götürərək qısa, dəqiq və texniki cəhətdən faydalı cavab ver. Azərbaycan dilində, aydın və
peşəkar tərzdə cavab ver (istifadəçi başqa dildə yazsa, o dildə cavab ver). Əgər kontekstdə axtarılan
göstərici (IP/domen/hash/CVE) tapılmayıbsa, bunu açıq şəkildə bildir və spekulyasiya etmə.
Cavablarını qısa saxla (adətən 3-6 cümlə və ya bullet-lər), lazım olduqda konkret rəqəmlərə istinad et."""


def _build_context(db: Session, user_message: str) -> dict:
    """İstifadəçi sualına uyğun yığcam kontekst hazırlayır (ümumi statistika + mesajda keçən
    dəyərlərə uyğun axtarış nəticələri, əgər varsa)."""
    total = db.query(IOC).count()
    by_source = dict(db.query(IOC.source, func.count(IOC.id)).group_by(IOC.source).all())
    by_severity = dict(db.query(IOC.severity, func.count(IOC.id)).group_by(IOC.severity).all())
    since_24h = datetime.utcnow() - timedelta(hours=24)
    new_24h = db.query(IOC).filter(IOC.created_at >= since_24h).count()

    top_threat_types = (
        db.query(IOC.threat_type, func.count(IOC.id).label("cnt"))
        .group_by(IOC.threat_type)
        .order_by(desc("cnt"))
        .limit(5)
        .all()
    )

    context = {
        "total_iocs": total,
        "new_last_24h": new_24h,
        "by_source": by_source,
        "by_severity": by_severity,
        "top_threat_types": [{"type": t or "unknown", "count": c} for t, c in top_threat_types],
    }

    # Mesajın içində konkret bir dəyər axtarılırsa (IP/domen/hash/CVE-yə bənzəyən token-lər),
    # bazada uyğunluq axtar və nəticəni əlavə et.
    tokens = [t.strip(".,:;()[]\"'") for t in user_message.split()]
    matches = []
    for token in tokens:
        if len(token) < 4:
            continue
        hits = (
            db.query(IOC)
            .filter(IOC.value.like(f"%{token}%"))
            .order_by(desc(IOC.last_seen))
            .limit(5)
            .all()
        )
        for h in hits:
            matches.append({
                "value": h.value,
                "type": h.ioc_type,
                "source": h.source,
                "threat_type": h.threat_type,
                "severity": h.severity,
                "confidence": h.confidence,
                "last_seen": h.last_seen.isoformat() if h.last_seen else None,
            })
    if matches:
        # dublikatları təmizlə
        seen = set()
        uniq = []
        for m in matches:
            key = (m["value"], m["source"])
            if key not in seen:
                seen.add(key)
                uniq.append(m)
        context["matched_iocs"] = uniq[:10]

    return context


def _available_models() -> list[str]:
    """ListModels ilə generateContent dəstəkləyən flash/pro modellərini tapır (1 saat keşlənir)."""
    now = time.time()
    if _model_cache["models"] and now - _model_cache["ts"] < 3600:
        return _model_cache["models"]
    models: list[str] = []
    try:
        resp = requests.get(
            "https://generativelanguage.googleapis.com/v1beta/models",
            params={"key": settings.GEMINI_API_KEY, "pageSize": 200},
            timeout=10,
        )
        if resp.ok:
            for m in resp.json().get("models", []):
                name = m.get("name", "").replace("models/", "")
                methods = m.get("supportedGenerationMethods", [])
                if "generateContent" not in methods:
                    continue
                if not name.startswith("gemini") or any(x in name for x in ("embed", "tts", "image", "audio", "live")):
                    continue
                models.append(name)
    except Exception as e:
        logger.warning(f"Gemini ListModels alınmadı: {e}")

    def rank(n: str) -> tuple:
        # flash-lar əvvəl (sürətli, ucuz), sonra lite, sonra pro; "preview/exp" sona
        return (
            0 if "flash" in n and "lite" not in n else 1 if "lite" in n else 2,
            1 if ("preview" in n or "exp" in n) else 0,
            -len(n),
        )

    ordered = []
    for n in GEMINI_FALLBACK_MODELS:  # sevdiyimiz ardıcıllıq əvvəl
        if not models or n in models:
            ordered.append(n)
    for n in sorted(models, key=rank):
        if n not in ordered:
            ordered.append(n)
    ordered = ordered[:8]
    _model_cache.update(models=ordered, ts=now)
    return ordered


def _local_answer(context: dict, question: str) -> str:
    """Gemini əlçatmaz olduqda bazadan qaydaya əsaslanan qısa cavab qurur."""
    q = question.lower()
    lines = []
    matched = context.get("matched_iocs")
    if matched:
        lines.append(f"Bazada sorğunuza uyğun {len(matched)} göstərici tapıldı:")
        for m in matched[:5]:
            lines.append(
                f"• {m['value']} ({m['type']}) — mənbə: {m['source']}, səviyyə: {m['severity']}, "
                f"təhdid: {m['threat_type'] or '-'}, güvən: {m['confidence']}"
            )
        return "\n".join(lines)

    by_source = context.get("by_source", {})
    by_sev = context.get("by_severity", {})
    if "mənbə" in q or "menbe" in q or "source" in q:
        if by_source:
            top = sorted(by_source.items(), key=lambda x: -x[1])
            lines.append(f"Ən çox IOC {top[0][0]} mənbəsindəndir ({top[0][1]} ədəd).")
            lines.append("Bölgü: " + ", ".join(f"{k}: {v}" for k, v in top))
    elif "kritik" in q or "critical" in q or "səviyyə" in q:
        lines.append(f"Kritik səviyyəli göstəricilər: {by_sev.get('critical', 0)}.")
        lines.append("Bütün səviyyələr: " + ", ".join(f"{k}: {v}" for k, v in by_sev.items()))
    else:
        lines.append(
            f"Bazada cəmi {context.get('total_iocs', 0)} IOC var, son 24 saatda {context.get('new_last_24h', 0)} yeni əlavə olunub."
        )
        if context.get("top_threat_types"):
            t = context["top_threat_types"][0]
            lines.append(f"Ən çox rast gəlinən təhdid növü: {t['type']} ({t['count']}).")
        if by_source:
            lines.append("Mənbələr üzrə: " + ", ".join(f"{k}: {v}" for k, v in by_source.items()))
    return "\n".join(lines) or "Bu sual üçün bazada uyğun məlumat tapılmadı."


def ask_gemini(db: Session, user_message: str, history: list[dict] | None = None) -> str:
    context = _build_context(db, user_message)

    if not settings.GEMINI_API_KEY:
        return _local_answer(context, user_message)

    contents = []
    for turn in (history or [])[-6:]:
        role = "user" if turn.get("role") == "user" else "model"
        contents.append({"role": role, "parts": [{"text": turn.get("text", "")}]})

    user_payload = (
        f"Kontekst (JSON):\n{json.dumps(context, ensure_ascii=False, default=str)}\n\n"
        f"Sual: {user_message}"
    )
    # history-nin son elementi elə bu sualdırsa, təkrarlamamaq üçün onu əvəz edirik
    if contents and contents[-1]["role"] == "user":
        contents[-1] = {"role": "user", "parts": [{"text": user_payload}]}
    else:
        contents.append({"role": "user", "parts": [{"text": user_payload}]})

    body = {
        "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "contents": contents,
        "generationConfig": {"temperature": 0.4, "maxOutputTokens": 700},
    }

    last_error = None
    for model in _available_models():
        for attempt in range(2):
            try:
                resp = requests.post(
                    _gemini_url(model),
                    params={"key": settings.GEMINI_API_KEY},
                    json=body,
                    timeout=25,
                )
            except Exception as e:
                last_error = f"{model}: {e}"
                break
            if resp.status_code == 404:
                last_error = f"{model}: 404"
                break  # növbəti modelə keç
            if resp.status_code in (429, 500, 503):
                last_error = f"{model}: {resp.status_code}"
                if attempt == 0:
                    time.sleep(1.5)
                    continue  # eyni modeli bir dəfə təkrar sına
                break  # sonra növbəti modelə keç
            if not resp.ok:
                last_error = f"{model}: {resp.status_code} {resp.text[:200]}"
                logger.error(f"Gemini xətası: {last_error}")
                break
            data = resp.json()
            candidates = data.get("candidates", [])
            parts = candidates[0].get("content", {}).get("parts", []) if candidates else []
            text = "".join(p.get("text", "") for p in parts).strip()
            if text:
                return text
            last_error = f"{model}: boş cavab"
            break

    logger.error(f"Gemini: bütün modellər uğursuz oldu, lokal cavaba keçilir. Son xəta: {last_error}")
    return (
        "⚠ Gemini hazırda çox yüklüdür, ona görə cavab bazadan avtomatik hazırlandı:\n\n"
        + _local_answer(context, user_message)
    )
