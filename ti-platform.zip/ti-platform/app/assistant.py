"""
AI Assistant modulu (Google Gemini).

Dashboard-dakı IOC datası üzərində sual-cavab imkanı verir: istifadəçi təbii dildə
sual verir ("son 24 saatda ən çox rast gəlinən təhdid növü nədir?", "bu IP təhlükəlidirmi: 1.2.3.4"
və s.), biz bazadan qısa bir kontekst çıxarıb Gemini-yə göndəririk və cavabı qaytarırıq.
"""
import json
import logging
from datetime import datetime, timedelta

import requests
from sqlalchemy import func, desc
from sqlalchemy.orm import Session

from app.config import settings
from app.database import IOC

logger = logging.getLogger("ti-platform.assistant")

# Google tez-tez model adlarını dəyişdiyi üçün bir neçə namizəd sınayırıq: birincisi ana keçərsə
# sıradakına düşür (məs. köhnə model "no longer available" deyirsə).
GEMINI_MODEL_CANDIDATES = ["gemini-3.8-flash", "gemini-2.5-flash", "gemini-2.0-flash", "gemini-flash-latest"]


def _gemini_url(model: str) -> str:
    return f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

SYSTEM_PROMPT = """Sən "SentryFeed" adlı Threat Intelligence Aggregation Platformasının daxili AI köməkçisisən.
Platforma AbuseIPDB, URLhaus, ThreatFox, AlienVault OTX və NVD kimi açıq mənbələrdən IOC (Indicator of
Compromise) toplayır: IP-lər, domenlər, URL-lər, hash-lər və CVE-lər.

Sənə hər sualla birlikdə bazadan çıxarılmış qısa JSON statistika/kontekst veriləcək. Bu konteksti
əsas götürərək qısa, dəqiq və texniki cəhətdən faydalı cavab ver. Azərbaycan dilində, aydın və
peşəkar tərzdə cavab ver (istifadəçi başqa dildə yazsa, o dildə cavab ver). Əgər kontekstdə axtarılan
göstərici (IP/domen/hash/CVE) tapılmayıbsa, bunu açıq şəkildə bildir və spekulyasiya etmə.
Cavablarını qısa saxla (adətən 3-6 cümlə və ya bullet-lər), lazım olduqda konkret rəqəmlərə istinad et."""


def _build_context(db: Session, user_message: str) -> dict:
    """İstifadəçi sualına uyğun yığcam kontekst hazırlayır (ümumi statistika + mesajda keçən
    dəyərlərə uyğun axtarış nəticələri, əgər varsa)."""
    total = db.query(IOC).count()
    by_source = dict(db.query(IOC.source, func.count(IOC.id)).group_by(IOC.source).all())
    by_severity = dict(db.query(IOC.severity, func.count(IOC.id)).group_by(IOC.severity).all())
    since_24h = datetime.utcnow() - timedelta(hours=24)
    new_24h = db.query(IOC).filter(IOC.created_at >= since_24h).count()

    top_threat_types = (
        db.query(IOC.threat_type, func.count(IOC.id).label("cnt"))
        .group_by(IOC.threat_type)
        .order_by(desc("cnt"))
        .limit(5)
        .all()
    )

    context = {
        "total_iocs": total,
        "new_last_24h": new_24h,
        "by_source": by_source,
        "by_severity": by_severity,
        "top_threat_types": [{"type": t or "unknown", "count": c} for t, c in top_threat_types],
    }

    # Mesajın içində konkret bir dəyər axtarılırsa (IP/domen/hash/CVE-yə bənzəyən token-lər),
    # bazada uyğunluq axtar və nəticəni əlavə et.
    tokens = [t.strip(".,:;()[]\"'") for t in user_message.split()]
    matches = []
    for token in tokens:
        if len(token) < 4:
            continue
        hits = (
            db.query(IOC)
            .filter(IOC.value.like(f"%{token}%"))
            .order_by(desc(IOC.last_seen))
            .limit(5)
            .all()
        )
        for h in hits:
            matches.append({
                "value": h.value,
                "type": h.ioc_type,
                "source": h.source,
                "threat_type": h.threat_type,
                "severity": h.severity,
                "confidence": h.confidence,
                "last_seen": h.last_seen.isoformat() if h.last_seen else None,
            })
    if matches:
        # dublikatları təmizlə
        seen = set()
        uniq = []
        for m in matches:
            key = (m["value"], m["source"])
            if key not in seen:
                seen.add(key)
                uniq.append(m)
        context["matched_iocs"] = uniq[:10]

    return context


def ask_gemini(db: Session, user_message: str, history: list[dict] | None = None) -> str:
    if not settings.GEMINI_API_KEY:
        return (
            "AI köməkçi hazırda konfiqurasiya edilməyib (GEMINI_API_KEY yoxdur). "
            "Administrator Render-də bu dəyişəni əlavə etməlidir."
        )

    context = _build_context(db, user_message)

    contents = []
    for turn in (history or [])[-6:]:
        role = "user" if turn.get("role") == "user" else "model"
        contents.append({"role": role, "parts": [{"text": turn.get("text", "")}]})

    user_payload = (
        f"Kontekst (JSON):\n{json.dumps(context, ensure_ascii=False, default=str)}\n\n"
        f"Sual: {user_message}"
    )
    contents.append({"role": "user", "parts": [{"text": user_payload}]})

    body = {
        "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
        "contents": contents,
        "generationConfig": {
            "temperature": 0.4,
            "maxOutputTokens": 500,
        },
    }

    last_error = None
    for model in GEMINI_MODEL_CANDIDATES:
        try:
            resp = requests.post(
                _gemini_url(model),
                params={"key": settings.GEMINI_API_KEY},
                json=body,
                timeout=20,
            )
            if resp.status_code == 404:
                # bu model artıq mövcud deyil, növbəti namizədi sına
                last_error = f"{model}: 404 {resp.text[:200]}"
                continue
            resp.raise_for_status()
            data = resp.json()
            candidates = data.get("candidates", [])
            if not candidates:
                return "AI köməkçidən cavab alınmadı (boş nəticə). Bir az sonra yenidən cəhd edin."
            parts = candidates[0].get("content", {}).get("parts", [])
            text = "".join(p.get("text", "") for p in parts).strip()
            return text or "AI köməkçidən cavab alınmadı."
        except requests.exceptions.HTTPError as e:
            logger.error(f"Gemini API HTTP error ({model}): {e} - {getattr(e.response, 'text', '')}")
            last_error = str(e)
        except Exception as e:
            logger.error(f"Gemini API error ({model}): {e}")
            last_error = str(e)

    logger.error(f"Gemini: bütün model namizədləri uğursuz oldu. Son xəta: {last_error}")
    return "AI köməkçi ilə əlaqədə xəta baş verdi (API xətası). Bir az sonra yenidən cəhd edin."
