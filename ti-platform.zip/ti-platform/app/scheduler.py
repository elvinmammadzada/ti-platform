"""
APScheduler ilə periodik data yeniləməsi.
"""
import logging
from apscheduler.schedulers.background import BackgroundScheduler

from app.config import settings
from app.aggregator import run_all_collectors

logger = logging.getLogger("ti-platform.scheduler")

scheduler = BackgroundScheduler()


def start_scheduler():
    scheduler.add_job(
        run_all_collectors,
        "interval",
        minutes=settings.FETCH_INTERVAL_MINUTES,
        id="fetch_all_sources",
        replace_existing=True,
        next_run_time=None,  # ilk işə salma FETCH_ON_STARTUP ilə main.py-da idarə olunur
    )
    scheduler.start()
    logger.info("Scheduler başladıldı: hər %s dəqiqədən bir yenilənmə", settings.FETCH_INTERVAL_MINUTES)


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown(wait=False)
