"""
Collector registry - hər mənbə (source) üçün fetch() funksiyasını qeydiyyata alır.
Yeni mənbə əlavə etmək üçün: yeni fayl yarat (app/collectors/xxx.py), fetch(db) funksiyası
yaz və aşağıdakı COLLECTORS lüğətinə əlavə et.
"""
from app.collectors import abuseipdb, urlhaus, threatfox, otx, nvd

COLLECTORS = {
    "abuseipdb": abuseipdb.fetch,
    "urlhaus": urlhaus.fetch,
    "threatfox": threatfox.fetch,
    "otx": otx.fetch,
    "nvd": nvd.fetch,
}
