"""
ThreatFox (abuse.ch) collector - IOC-lar (malware C2 IP/domain/URL/hash) paylaşan platforma.
Sənədləşdirmə: https://threatfox.abuse.ch/api/
Qeyd: abuse.ch pulsuz "Auth-Key" tələb edir (auth.abuse.ch saytından qeydiyyat).
"""
import json
import requests
from sqlalchemy.orm import Session

from app.config import settings
from app.collectors.base import upsert_ioc

SOURCE = "threatfox"
API_URL = "https://threatfox-api.abuse.ch/api/v1/"

# ThreatFox ioc_type -> bizim daxili ioc_type
TYPE_MAP = {
    "ip:port": "ip",
    "domain": "domain",
    "url": "url",
    "md5_hash": "hash",
    "sha1_hash": "hash",
    "sha256_hash": "hash",
}


def fetch(db: Session) -> dict:
    if not settings.ENABLE_THREATFOX:
        return {"status": "skipped", "message": "Mənbə deaktivdir", "fetched": 0, "new": 0}
    if not settings.THREATFOX_AUTH_KEY:
        return {
            "status": "skipped",
            "message": "THREATFOX_AUTH_KEY .env-də təyin edilməyib (auth.abuse.ch saytından pulsuz alına bilər)",
            "fetched": 0,
            "new": 0,
        }

    headers = {"Auth-Key": settings.THREATFOX_AUTH_KEY, "Content-Type": "application/json"}
    body = {"query": "get_iocs", "days": 3}

    try:
        resp = requests.post(API_URL, headers=headers, data=json.dumps(body), timeout=30)
        resp.raise_for_status()
        payload = resp.json()
    except Exception as e:
        return {"status": "error", "message": f"Sorğu xətası: {e}", "fetched": 0, "new": 0}

    if payload.get("query_status") != "ok":
        return {"status": "error", "message": f"API cavabı: {payload.get('query_status')}", "fetched": 0, "new": 0}

    items = (payload.get("data") or [])[: settings.THREATFOX_LIMIT]
    new_count = 0
    for item in items:
        raw_type = item.get("ioc_type", "")
        ioc_type = TYPE_MAP.get(raw_type, "other")
        value = item.get("ioc")
        confidence = float(item.get("confidence_level", 50))
        severity = "critical" if confidence >= 90 else "high" if confidence >= 70 else "medium"
        tags = item.get("tags") or []
        tags_str = ",".join(tags) if isinstance(tags, list) else str(tags or "")
        is_new = upsert_ioc(
            db,
            ioc_type=ioc_type,
            value=value,
            source=SOURCE,
            threat_type=item.get("malware_printable", item.get("threat_type", "unknown")),
            confidence=confidence,
            severity=severity,
            tags=tags_str,
            description=item.get("malware_printable", ""),
            raw_json=json.dumps(item),
        )
        if is_new:
            new_count += 1

    return {"status": "success", "message": "OK", "fetched": len(items), "new": new_count}
