"""
AlienVault OTX (Open Threat Exchange) collector - icma tərəfindən paylaşılan "pulse"lardakı IOC-lar.
Sənədləşdirmə: https://otx.alienvault.com/api
Pulsuz API key lazımdır (otx.alienvault.com-da qeydiyyatdan sonra profil səhifəsindən alınır).
"""
import json
import requests
from sqlalchemy.orm import Session

from app.config import settings
from app.collectors.base import upsert_ioc

SOURCE = "otx"
API_URL = "https://otx.alienvault.com/api/v1/pulses/subscribed"

OTX_TYPE_MAP = {
    "IPv4": "ip",
    "IPv6": "ip",
    "domain": "domain",
    "hostname": "domain",
    "URL": "url",
    "FileHash-MD5": "hash",
    "FileHash-SHA1": "hash",
    "FileHash-SHA256": "hash",
    "CVE": "cve",
}


def fetch(db: Session) -> dict:
    if not settings.ENABLE_OTX:
        return {"status": "skipped", "message": "Mənbə deaktivdir", "fetched": 0, "new": 0}
    if not settings.OTX_API_KEY:
        return {"status": "skipped", "message": "OTX_API_KEY .env-də təyin edilməyib", "fetched": 0, "new": 0}

    headers = {"X-OTX-API-KEY": settings.OTX_API_KEY}
    params = {"limit": 20, "page": 1}

    try:
        resp = requests.get(API_URL, headers=headers, params=params, timeout=30)
        resp.raise_for_status()
        payload = resp.json()
    except Exception as e:
        return {"status": "error", "message": f"Sorğu xətası: {e}", "fetched": 0, "new": 0}

    pulses = payload.get("results", [])
    total_indicators = 0
    new_count = 0
    for pulse in pulses:
        pulse_name = pulse.get("name", "")
        for indicator in pulse.get("indicators", []):
            raw_type = indicator.get("type", "")
            ioc_type = OTX_TYPE_MAP.get(raw_type, "other")
            value = indicator.get("indicator")
            total_indicators += 1
            is_new = upsert_ioc(
                db,
                ioc_type=ioc_type,
                value=value,
                source=SOURCE,
                threat_type=pulse_name[:128],
                confidence=60.0,
                severity="medium",
                description=indicator.get("description", "")[:500],
                raw_json=json.dumps(indicator),
            )
            if is_new:
                new_count += 1

    return {"status": "success", "message": "OK", "fetched": total_indicators, "new": new_count}
