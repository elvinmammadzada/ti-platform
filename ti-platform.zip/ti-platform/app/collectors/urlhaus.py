"""
URLhaus (abuse.ch) collector - zərərli proqram yayan URL-lərin siyahısı.
Sənədləşdirmə: https://urlhaus-api.abuse.ch/
Qeyd: abuse.ch 2023-cü ildən pulsuz "Auth-Key" tələb edir (auth.abuse.ch saytından
qeydiyyatdan keçib əldə edilir). Əgər açar yoxdursa, ictimai bulk JSON dump-a
fallback edilir (auth tələb etmir, lakin real-time deyil).
"""
import json
import requests
from sqlalchemy.orm import Session

from app.config import settings
from app.collectors.base import upsert_ioc

SOURCE = "urlhaus"
API_URL = "https://urlhaus-api.abuse.ch/v1/urls/recent/"
FALLBACK_URL = "https://urlhaus.abuse.ch/downloads/json_recent/"


def _severity_from_status(status: str) -> str:
    return "high" if status == "online" else "medium"


def fetch(db: Session) -> dict:
    if not settings.ENABLE_URLHAUS:
        return {"status": "skipped", "message": "Mənbə deaktivdir", "fetched": 0, "new": 0}

    items = []
    try:
        if settings.URLHAUS_AUTH_KEY:
            headers = {"Auth-Key": settings.URLHAUS_AUTH_KEY}
            resp = requests.post(API_URL, headers=headers, timeout=30)
            resp.raise_for_status()
            payload = resp.json()
            items = payload.get("urls", [])
        else:
            resp = requests.get(FALLBACK_URL, timeout=30)
            resp.raise_for_status()
            payload = resp.json()
            # fallback formatı: {"<id>": [{...}], ...}
            for entries in payload.values():
                if isinstance(entries, list):
                    items.extend(entries)
    except Exception as e:
        return {"status": "error", "message": f"Sorğu xətası: {e}", "fetched": 0, "new": 0}

    items = items[: settings.URLHAUS_LIMIT]
    new_count = 0
    for item in items:
        url_value = item.get("url")
        status = item.get("url_status", "unknown")
        tags = item.get("tags") or []
        tags_str = ",".join(tags) if isinstance(tags, list) else str(tags)
        is_new = upsert_ioc(
            db,
            ioc_type="url",
            value=url_value,
            source=SOURCE,
            threat_type=item.get("threat", "malware_download"),
            confidence=80.0 if status == "online" else 50.0,
            severity=_severity_from_status(status),
            tags=tags_str,
            description=f"URLhaus status: {status}, host: {item.get('host', '')}",
            raw_json=json.dumps(item),
        )
        if is_new:
            new_count += 1

    return {"status": "success", "message": "OK", "fetched": len(items), "new": new_count}
