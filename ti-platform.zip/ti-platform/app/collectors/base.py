"""
Bütün collector-lar üçün ortaq köməkçi funksiyalar.
"""
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from app.database import IOC


def upsert_ioc(db: Session, ioc_type: str, value: str, source: str, **kwargs) -> bool:
    """
    IOC-u bazaya yazır. Əgər (type, value, source) artıq varsa - last_seen yeniləyir.
    Yeni yazıldısa True, mövcud yeniləndisə False qaytarır.
    """
    if not value:
        return False

    existing = (
        db.query(IOC)
        .filter(IOC.ioc_type == ioc_type, IOC.value == value, IOC.source == source)
        .first()
    )
    if existing:
        existing.last_seen = datetime.utcnow()
        for k, v in kwargs.items():
            if hasattr(existing, k) and v is not None:
                setattr(existing, k, v)
        try:
            db.commit()
        except IntegrityError:
            db.rollback()
        return False

    ioc = IOC(
        ioc_type=ioc_type,
        value=value,
        source=source,
        first_seen=kwargs.pop("first_seen", None) or datetime.utcnow(),
        last_seen=datetime.utcnow(),
        **kwargs,
    )
    db.add(ioc)
    try:
        db.commit()
        return True
    except IntegrityError:
        db.rollback()
        return False
