"""
AbuseIPDB collector - zərərli fəaliyyəti bildirilmiş IP-lərin "blacklist" siyahısı.
Sənədləşdirmə: https://docs.abuseipdb.com/#blacklist-endpoint
Pulsuz hesabda gündəlik limit var (~1000 sorğu), key tələb olunur.
"""
import json
import requests
from sqlalchemy.orm import Session

from app.config import settings
from app.collectors.base import upsert_ioc

SOURCE = "abuseipdb"
URL = "https://api.abuseipdb.com/api/v2/blacklist"


def fetch(db: Session) -> dict:
    if not settings.ENABLE_ABUSEIPDB:
        return {"status": "skipped", "message": "Mənbə deaktivdir", "fetched": 0, "new": 0}
    if not settings.ABUSEIPDB_API_KEY:
        return {"status": "skipped", "message": "ABUSEIPDB_API_KEY .env-də təyin edilməyib", "fetched": 0, "new": 0}

    headers = {"Key": settings.ABUSEIPDB_API_KEY, "Accept": "application/json"}
    params = {"confidenceMinimum": 75, "limit": settings.ABUSEIPDB_LIMIT}

    try:
        resp = requests.get(URL, headers=headers, params=params, timeout=30)
        resp.raise_for_status()
        payload = resp.json()
    except Exception as e:
        return {"status": "error", "message": f"Sorğu xətası: {e}", "fetched": 0, "new": 0}

    items = payload.get("data", [])
    new_count = 0
    for item in items:
        ip = item.get("ipAddress")
        score = item.get("abuseConfidenceScore", 0)
        severity = "critical" if score >= 90 else "high" if score >= 70 else "medium" if score >= 40 else "low"
        is_new = upsert_ioc(
            db,
            ioc_type="ip",
            value=ip,
            source=SOURCE,
            threat_type="malicious_activity",
            confidence=float(score),
            severity=severity,
            country=item.get("countryCode") or "",
            description=f"AbuseIPDB confidence score: {score}",
            raw_json=json.dumps(item),
        )
        if is_new:
            new_count += 1

    return {"status": "success", "message": "OK", "fetched": len(items), "new": new_count}
