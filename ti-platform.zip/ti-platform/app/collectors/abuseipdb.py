"""
AbuseIPDB collector - zərərli fəaliyyəti bildirilmiş IP-lərin "blacklist" siyahısı.
Sənədləşdirmə: https://docs.abuseipdb.com/#blacklist-endpoint
Pulsuz hesabda /blacklist endpoint-i üçün gündəlik limit cəmi 5 sorğudur, ona görə
sorğuları eyni proses daxilində ən azı 6 saatda bir dəfə göndəririk.
"""
import json
import time
import requests
from sqlalchemy.orm import Session

from app.config import settings
from app.collectors.base import upsert_ioc

SOURCE = "abuseipdb"
URL = "https://api.abuseipdb.com/api/v2/blacklist"
MIN_INTERVAL_SEC = 6 * 3600
_state = {"last_success": 0.0}


def fetch(db: Session) -> dict:
    if not settings.ENABLE_ABUSEIPDB:
        return {"status": "skipped", "message": "Mənbə deaktivdir", "fetched": 0, "new": 0}
    if not settings.ABUSEIPDB_API_KEY:
        return {"status": "skipped", "message": "ABUSEIPDB_API_KEY .env-də təyin edilməyib", "fetched": 0, "new": 0}

    since = time.time() - _state["last_success"]
    if _state["last_success"] and since < MIN_INTERVAL_SEC:
        left = int((MIN_INTERVAL_SEC - since) / 60)
        return {
            "status": "skipped",
            "message": f"Gündəlik limitə qənaət üçün atlandı (növbəti sorğu ~{left} dəq sonra)",
            "fetched": 0, "new": 0,
        }

    headers = {"Key": settings.ABUSEIPDB_API_KEY, "Accept": "application/json"}
    params = {"confidenceMinimum": 75, "limit": settings.ABUSEIPDB_LIMIT}

    try:
        resp = requests.get(URL, headers=headers, params=params, timeout=30)
    except Exception as e:
        return {"status": "error", "message": f"Şəbəkə xətası: {type(e).__name__}", "fetched": 0, "new": 0}

    if resp.status_code == 429:
        return {
            "status": "error",
            "message": "AbuseIPDB gündəlik limiti bitib (pulsuz plan: 5 sorğu/gün). Limit sabah yenilənəcək.",
            "fetched": 0, "new": 0,
        }
    if resp.status_code in (401, 403):
        return {"status": "error", "message": "API açarı etibarsızdır və ya icazə yoxdur", "fetched": 0, "new": 0}
    if not resp.ok:
        return {"status": "error", "message": f"AbuseIPDB HTTP {resp.status_code}", "fetched": 0, "new": 0}
    try:
        payload = resp.json()
    except ValueError:
        return {"status": "error", "message": "AbuseIPDB cavabı JSON deyil", "fetched": 0, "new": 0}
    _state["last_success"] = time.time()

    items = payload.get("data", [])
    new_count = 0
    for item in items:
        ip = item.get("ipAddress")
        score = item.get("abuseConfidenceScore", 0)
        severity = "critical" if score >= 90 else "high" if score >= 70 else "medium" if score >= 40 else "low"
        is_new = upsert_ioc(
            db,
            ioc_type="ip",
            value=ip,
            source=SOURCE,
            threat_type="malicious_activity",
            confidence=float(score),
            severity=severity,
            country=item.get("countryCode") or "",
            description=f"AbuseIPDB confidence score: {score}",
            raw_json=json.dumps(item),
        )
        if is_new:
            new_count += 1

    return {"status": "success", "message": "OK", "fetched": len(items), "new": new_count}
