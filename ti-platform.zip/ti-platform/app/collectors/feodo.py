"""
abuse.ch Feodo Tracker collector - botnet C2 serverlərinin IP blocklist-i.
API açarı tələb olunmur. AbuseIPDB-nin gündəlik limiti bitdikdə də IP datası olsun deyə
əlavə açarsız IP mənbəyi kimi istifadə olunur.
Sənəd: https://feodotracker.abuse.ch/blocklist/
"""
import json
import requests
from sqlalchemy.orm import Session

from app.collectors.base import upsert_ioc

SOURCE = "feodo"
URL = "https://feodotracker.abuse.ch/downloads/ipblocklist.json"


def fetch(db: Session) -> dict:
    try:
        resp = requests.get(URL, timeout=30)
    except Exception as e:
        return {"status": "error", "message": f"Şəbəkə xətası: {type(e).__name__}", "fetched": 0, "new": 0}
    if not resp.ok:
        return {"status": "error", "message": f"Feodo Tracker HTTP {resp.status_code}", "fetched": 0, "new": 0}
    try:
        items = resp.json()
    except ValueError:
        return {"status": "error", "message": "Feodo cavabı JSON deyil", "fetched": 0, "new": 0}
    if isinstance(items, dict):
        items = items.get("data", []) or []

    new_count = 0
    for item in items[:1000]:
        ip = item.get("ip_address")
        if not ip:
            continue
        online = (item.get("status") or "").lower() == "online"
        malware = item.get("malware") or "botnet_c2"
        is_new = upsert_ioc(
            db,
            ioc_type="ip",
            value=ip,
            source=SOURCE,
            threat_type=f"botnet_cc ({malware})",
            confidence=100.0 if online else 75.0,
            severity="critical" if online else "high",
            country=item.get("country") or "",
            description=f"{malware} C2 · port {item.get('port', '-')} · {item.get('as_name') or ''}".strip(),
            raw_json=json.dumps(item),
        )
        if is_new:
            new_count += 1

    return {"status": "success", "message": "OK", "fetched": len(items), "new": new_count}
