"""
NVD (National Vulnerability Database) collector - son CVE qeydləri.
Sənədləşdirmə: https://nvd.nist.gov/developers/vulnerabilities
API key tələb olunmur (key olmadan rate-limit daha aşağıdır: 5 sorğu/30san).
"""
import json
import requests
from sqlalchemy.orm import Session

from app.config import settings
from app.collectors.base import upsert_ioc

SOURCE = "nvd"
API_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"


def _severity_from_cvss(metrics: dict) -> tuple[str, float]:
    for key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        arr = metrics.get(key)
        if arr:
            data = arr[0].get("cvssData", {})
            score = data.get("baseScore", 0.0)
            severity = arr[0].get("baseSeverity") or data.get("baseSeverity") or "unknown"
            return str(severity).lower(), float(score)
    return "unknown", 0.0


def fetch(db: Session) -> dict:
    if not settings.ENABLE_NVD:
        return {"status": "skipped", "message": "Mənbə deaktivdir", "fetched": 0, "new": 0}

    headers = {}
    if settings.NVD_API_KEY:
        headers["apiKey"] = settings.NVD_API_KEY

    params = {"resultsPerPage": 50, "startIndex": 0}

    try:
        resp = requests.get(API_URL, headers=headers, params=params, timeout=30)
        resp.raise_for_status()
        payload = resp.json()
    except Exception as e:
        return {"status": "error", "message": f"Sorğu xətası: {e}", "fetched": 0, "new": 0}

    items = payload.get("vulnerabilities", [])
    new_count = 0
    for item in items:
        cve = item.get("cve", {})
        cve_id = cve.get("id")
        descriptions = cve.get("descriptions", [])
        desc_text = next((d["value"] for d in descriptions if d.get("lang") == "en"), "")
        metrics = cve.get("metrics", {})
        severity, score = _severity_from_cvss(metrics)
        is_new = upsert_ioc(
            db,
            ioc_type="cve",
            value=cve_id,
            source=SOURCE,
            threat_type="vulnerability",
            confidence=score * 10,  # 0-10 -> 0-100 miqyasına çevrilir
            severity=severity,
            description=desc_text[:500],
            raw_json=json.dumps(cve)[:5000],
        )
        if is_new:
            new_count += 1

    return {"status": "success", "message": "OK", "fetched": len(items), "new": new_count}
