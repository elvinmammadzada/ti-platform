const API = "";

const state = {
  page: 0,
  limit: 25,
  filters: { source: "", ioc_type: "", severity: "", q: "" },
};

let sourceChart, typeChart, trendChart;

const SEVERITY_ORDER = ["critical", "high", "medium", "low", "unknown"];
const CHART_COLORS = ["#4f8cff", "#7c5cff", "#4dd4ac", "#ff9f43", "#ff4d6d", "#ffd166", "#6b7690"];

function fmtDate(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  return d.toLocaleString("az-AZ", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

async function fetchJSON(url, opts) {
  const res = await fetch(url, opts);
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  return res.json();
}

async function loadStats() {
  const stats = await fetchJSON("/api/stats");
  document.getElementById("kpi-total").textContent = stats.total.toLocaleString();
  document.getElementById("kpi-new24").textContent = stats.new_last_24h.toLocaleString();
  document.getElementById("kpi-critical").textContent = (stats.by_severity.critical || 0).toLocaleString();
  document.getElementById("kpi-sources").textContent = Object.keys(stats.by_source).length;

  renderSourceChart(stats.by_source);
  renderTypeChart(stats.by_type);
  renderTrendChart(stats.daily_trend);
}

function renderSourceChart(bySource) {
  const ctx = document.getElementById("chart-source");
  const labels = Object.keys(bySource);
  const data = Object.values(bySource);
  if (sourceChart) sourceChart.destroy();
  sourceChart = new Chart(ctx, {
    type: "doughnut",
    data: { labels, datasets: [{ data, backgroundColor: CHART_COLORS, borderWidth: 0 }] },
    options: {
      plugins: { legend: { position: "bottom", labels: { color: "#8b96b3", boxWidth: 10, font: { size: 11 } } } },
      cutout: "65%",
    },
  });
}

function renderTypeChart(byType) {
  const ctx = document.getElementById("chart-type");
  const labels = Object.keys(byType);
  const data = Object.values(byType);
  if (typeChart) typeChart.destroy();
  typeChart = new Chart(ctx, {
    type: "bar",
    data: { labels, datasets: [{ data, backgroundColor: "#4f8cff", borderRadius: 6 }] },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color: "#8b96b3" }, grid: { display: false } },
        y: { ticks: { color: "#8b96b3" }, grid: { color: "#263049" }, beginAtZero: true },
      },
    },
  });
}

function renderTrendChart(trend) {
  const ctx = document.getElementById("chart-trend");
  const labels = trend.map((t) => t.date);
  const data = trend.map((t) => t.count);
  if (trendChart) trendChart.destroy();
  trendChart = new Chart(ctx, {
    type: "line",
    data: {
      labels,
      datasets: [
        {
          data,
          borderColor: "#7c5cff",
          backgroundColor: "rgba(124,92,255,0.15)",
          fill: true,
          tension: 0.35,
          pointRadius: 3,
        },
      ],
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color: "#8b96b3" }, grid: { display: false } },
        y: { ticks: { color: "#8b96b3" }, grid: { color: "#263049" }, beginAtZero: true },
      },
    },
  });
}

async function loadSources() {
  const data = await fetchJSON("/api/sources");
  const list = document.getElementById("sources-list");
  list.innerHTML = "";
  const filterSelect = document.getElementById("filter-source");
  filterSelect.innerHTML = '<option value="">Bütün mənbələr</option>';

  data.sources.forEach((src) => {
    const isOn = data.enabled[src];
    const chip = document.createElement("div");
    chip.className = "source-chip";
    chip.innerHTML = `<span class="dot ${isOn ? "on" : "off"}"></span> ${src} ${isOn ? "" : "(key yoxdur)"}`;
    list.appendChild(chip);

    const opt = document.createElement("option");
    opt.value = src;
    opt.textContent = src;
    filterSelect.appendChild(opt);
  });
}

function severityBadge(sev) {
  const s = SEVERITY_ORDER.includes(sev) ? sev : "unknown";
  return `<span class="badge ${s}">${s}</span>`;
}

async function loadIOCs() {
  const params = new URLSearchParams({
    limit: state.limit,
    offset: state.page * state.limit,
  });
  if (state.filters.source) params.set("source", state.filters.source);
  if (state.filters.ioc_type) params.set("ioc_type", state.filters.ioc_type);
  if (state.filters.severity) params.set("severity", state.filters.severity);
  if (state.filters.q) params.set("q", state.filters.q);

  const data = await fetchJSON(`/api/iocs?${params.toString()}`);
  const tbody = document.getElementById("ioc-tbody");
  tbody.innerHTML = "";

  if (data.items.length === 0) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="7">Nəticə tapılmadı. Mənbələri yeniləməyi yoxlayın.</td></tr>`;
  } else {
    data.items.forEach((ioc) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="mono">${ioc.value}</td>
        <td>${ioc.ioc_type}</td>
        <td>${ioc.source}</td>
        <td>${ioc.threat_type || "-"}</td>
        <td>${severityBadge(ioc.severity)}</td>
        <td>${ioc.confidence?.toFixed(0) ?? "-"}</td>
        <td>${fmtDate(ioc.last_seen)}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  const totalPages = Math.max(1, Math.ceil(data.total / state.limit));
  document.getElementById("page-info").textContent = `Səhifə ${state.page + 1} / ${totalPages} (cəmi ${data.total})`;
  document.getElementById("prev-page").disabled = state.page === 0;
  document.getElementById("next-page").disabled = state.page + 1 >= totalPages;
}

function setupFilters() {
  document.getElementById("search-input").addEventListener("input", debounce((e) => {
    state.filters.q = e.target.value;
    state.page = 0;
    loadIOCs();
  }, 400));
  document.getElementById("filter-source").addEventListener("change", (e) => {
    state.filters.source = e.target.value;
    state.page = 0;
    loadIOCs();
  });
  document.getElementById("filter-type").addEventListener("change", (e) => {
    state.filters.ioc_type = e.target.value;
    state.page = 0;
    loadIOCs();
  });
  document.getElementById("filter-severity").addEventListener("change", (e) => {
    state.filters.severity = e.target.value;
    state.page = 0;
    loadIOCs();
  });
  document.getElementById("prev-page").addEventListener("click", () => {
    if (state.page > 0) { state.page--; loadIOCs(); }
  });
  document.getElementById("next-page").addEventListener("click", () => {
    state.page++; loadIOCs();
  });
}

function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

async function refreshAll() {
  const btn = document.getElementById("refresh-btn");
  btn.disabled = true;
  btn.textContent = "Yenilənir...";
  try {
    await fetchJSON("/api/refresh", { method: "POST" });
    document.getElementById("last-updated").textContent = "Yeniləmə arxa planda gedir, bir neçə saniyəyə nəticə görünəcək...";
    setTimeout(async () => {
      await refreshDashboard();
      btn.disabled = false;
      btn.textContent = "↻ Bütün mənbələri yenilə";
    }, 6000);
  } catch (e) {
    btn.disabled = false;
    btn.textContent = "↻ Bütün mənbələri yenilə";
    console.error(e);
  }
}

async function refreshDashboard() {
  await Promise.all([loadStats(), loadSources(), loadIOCs()]);
  document.getElementById("last-updated").textContent = "Son yenilənmə: " + new Date().toLocaleTimeString("az-AZ");
}

document.getElementById("refresh-btn").addEventListener("click", refreshAll);
setupFilters();
refreshDashboard();
setInterval(refreshDashboard, 60000); // hər 60 saniyədən bir dashboard-u avtomatik yenilə
