/* ==========================================================================
   SentryFeed — Threat Intelligence Platform dashboard
   ========================================================================== */

const state = {
  page: 0,
  limit: 25,
  filters: { source: "", ioc_type: "", severity: "", q: "" },
  sort: { field: "last_seen", dir: "desc" },
  lastIocs: [],
};

let sourceChart, typeChart, trendChart;

const SEVERITY_ORDER = ["critical", "high", "medium", "low", "unknown"];
const SEVERITY_COLOR = {
  critical: "#e6484a",
  high: "#ec835a",
  medium: "#fab219",
  low: "#0ca30c",
  unknown: "#5b637a",
};
const CAT_COLORS = ["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#9085e9"];
const TYPE_COLORS = { ip: "#3987e5", url: "#d95926", domain: "#199e70", hash: "#c98500", cve: "#d55181", other: "#9085e9" };

function fmtDate(iso) {
  if (!iso) return "-";
  const d = new Date(iso);
  return d.toLocaleString("az-AZ", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

function relTime(iso) {
  if (!iso) return "heç vaxt";
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "indicə";
  if (mins < 60) return `${mins} dəq əvvəl`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} saat əvvəl`;
  const days = Math.floor(hours / 24);
  return `${days} gün əvvəl`;
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function countryFlag(code) {
  if (!code || code.length !== 2) return "🌐";
  const upper = code.toUpperCase();
  const base = 127397;
  return String.fromCodePoint(...[...upper].map((c) => base + c.charCodeAt(0)));
}

async function fetchJSON(url, opts) {
  const res = await fetch(url, opts);
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  return res.json();
}

/* ---------------------------- navigation ---------------------------- */
const PAGE_META = {
  overview: ["Ümumi baxış", "Bütün mənbələrdən toplanan təhdid göstəricilərinin xülasəsi"],
  iocs: ["IOC Explorer", "Bazadakı bütün göstəriciləri axtar, filtrlə və ixrac et"],
  sources: ["Mənbələr", "Hər inteqrasiyanın statusu və idarəetməsi"],
  activity: ["Fəaliyyət jurnalı", "Collector-ların işə düşmə tarixçəsi"],
  assistant: ["AI Köməkçi", "Gemini əsaslı təhlil köməkçisi ilə bazanız üzrə söhbət edin"],
  about: ["Layihə haqqında", "Arxitektura və məqsəd"],
};

function setupNav() {
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("click", () => {
      const view = item.dataset.view;
      document.querySelectorAll(".nav-item").forEach((i) => i.classList.remove("active"));
      item.classList.add("active");
      document.querySelectorAll(".view").forEach((v) => v.classList.add("hidden"));
      document.getElementById(`view-${view}`).classList.remove("hidden");
      const [title, sub] = PAGE_META[view];
      document.getElementById("page-title").textContent = title;
      document.getElementById("page-subtitle").textContent = sub;
    });
  });
}

function startClock() {
  const el = document.getElementById("clock");
  function tick() {
    el.textContent = new Date().toLocaleTimeString("az-AZ", { hour12: false });
  }
  tick();
  setInterval(tick, 1000);
}

/* ---------------------------- stats / charts ---------------------------- */
async function loadStats() {
  const stats = await fetchJSON("/api/stats");

  document.getElementById("kpi-total").textContent = stats.total.toLocaleString();
  document.getElementById("kpi-new24").textContent = stats.new_last_24h.toLocaleString();
  document.getElementById("kpi-critical").textContent = (stats.by_severity.critical || 0).toLocaleString();
  document.getElementById("kpi-sources").textContent = Object.keys(stats.by_source).length;
  document.getElementById("kpi-confidence").textContent = stats.avg_confidence.toFixed(0) + "%";

  const deltaEl = document.getElementById("kpi-total-delta");
  const pct = stats.trend_pct;
  if (pct > 0) {
    deltaEl.textContent = `▲ ${pct}%`;
    deltaEl.className = "kpi-delta up";
  } else if (pct < 0) {
    deltaEl.textContent = `▼ ${Math.abs(pct)}%`;
    deltaEl.className = "kpi-delta down";
  } else {
    deltaEl.textContent = "— 0%";
    deltaEl.className = "kpi-delta flat";
  }

  renderSourceChart(stats.by_source);
  renderTypeChart(stats.by_type);
  renderTrendChart(stats.daily_trend);
  renderSeverityStack(stats.by_severity, stats.total);
  renderRankList("threat-type-list", stats.top_threat_types.map((t) => ({ name: t.name, count: t.count })));
  renderRankList(
    "country-list",
    stats.top_countries.map((c) => ({ name: `${countryFlag(c.code)} ${c.code}`, count: c.count }))
  );
}

function renderSourceChart(bySource) {
  const ctx = document.getElementById("chart-source");
  const labels = Object.keys(bySource);
  const data = Object.values(bySource);
  const colors = labels.map((_, i) => CAT_COLORS[i % CAT_COLORS.length]);

  if (sourceChart) sourceChart.destroy();
  sourceChart = new Chart(ctx, {
    type: "doughnut",
    data: { labels, datasets: [{ data, backgroundColor: colors, borderWidth: 2, borderColor: "#131926" }] },
    options: {
      cutout: "68%",
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "#1a2132",
          borderColor: "#232b3d",
          borderWidth: 1,
          padding: 10,
          titleColor: "#eef1f8",
          bodyColor: "#c3c9d9",
        },
      },
    },
  });

  const legendEl = document.getElementById("legend-source");
  legendEl.innerHTML = labels
    .map((l, i) => `<div class="legend-item"><span class="legend-swatch" style="background:${colors[i]}"></span>${l}</div>`)
    .join("");
}

function renderTypeChart(byType) {
  const ctx = document.getElementById("chart-type");
  const labels = Object.keys(byType);
  const data = Object.values(byType);
  const colors = labels.map((l) => TYPE_COLORS[l] || "#5b637a");

  if (typeChart) typeChart.destroy();
  typeChart = new Chart(ctx, {
    type: "bar",
    data: { labels, datasets: [{ data, backgroundColor: colors, borderRadius: 6, maxBarThickness: 42 }] },
    options: {
      plugins: {
        legend: { display: false },
        tooltip: { backgroundColor: "#1a2132", borderColor: "#232b3d", borderWidth: 1, padding: 10 },
      },
      scales: {
        x: { ticks: { color: "#8991a8" }, grid: { display: false } },
        y: { ticks: { color: "#8991a8" }, grid: { color: "#1c2333" }, beginAtZero: true },
      },
    },
  });
}

function renderTrendChart(trend) {
  const ctx = document.getElementById("chart-trend");
  const labels = trend.map((t) => t.date.slice(5));
  const data = trend.map((t) => t.count);

  if (trendChart) trendChart.destroy();
  const gradient = ctx.getContext("2d").createLinearGradient(0, 0, 0, 200);
  gradient.addColorStop(0, "rgba(57,135,229,0.35)");
  gradient.addColorStop(1, "rgba(57,135,229,0.0)");

  trendChart = new Chart(ctx, {
    type: "line",
    data: {
      labels,
      datasets: [
        {
          data,
          borderColor: "#3987e5",
          backgroundColor: gradient,
          fill: true,
          tension: 0.35,
          pointRadius: 3,
          pointBackgroundColor: "#3987e5",
          pointBorderColor: "#0a0d16",
          pointBorderWidth: 2,
        },
      ],
    },
    options: {
      plugins: {
        legend: { display: false },
        tooltip: { backgroundColor: "#1a2132", borderColor: "#232b3d", borderWidth: 1, padding: 10 },
      },
      scales: {
        x: { ticks: { color: "#8991a8" }, grid: { display: false } },
        y: { ticks: { color: "#8991a8" }, grid: { color: "#1c2333" }, beginAtZero: true },
      },
    },
  });
}

function renderSeverityStack(bySeverity, total) {
  const stackEl = document.getElementById("severity-stack");
  const legendEl = document.getElementById("severity-legend");
  stackEl.innerHTML = "";
  legendEl.innerHTML = "";

  SEVERITY_ORDER.forEach((sev) => {
    const count = bySeverity[sev] || 0;
    const pct = total > 0 ? (count / total) * 100 : 0;
    if (pct > 0) {
      const seg = document.createElement("div");
      seg.className = "stacked-seg";
      seg.style.width = pct + "%";
      seg.style.background = SEVERITY_COLOR[sev];
      seg.title = `${sev}: ${count}`;
      stackEl.appendChild(seg);
    }
    const row = document.createElement("div");
    row.className = "sev-row";
    row.innerHTML = `
      <span class="sev-dot" style="background:${SEVERITY_COLOR[sev]}"></span>
      <span class="sev-name">${sev}</span>
      <span class="sev-count">${count.toLocaleString()}</span>
    `;
    legendEl.appendChild(row);
  });
}

function renderRankList(elId, items) {
  const el = document.getElementById(elId);
  if (!items.length) {
    el.innerHTML = `<div style="color:var(--text-mute);font-size:12.5px;">Məlumat yoxdur</div>`;
    return;
  }
  const max = Math.max(...items.map((i) => i.count), 1);
  el.innerHTML = items
    .slice(0, 8)
    .map(
      (item, i) => `
      <div class="rank-row">
        <div class="rank-idx">${i + 1}</div>
        <div class="rank-body">
          <div class="rank-top">
            <span class="rank-name">${item.name}</span>
            <span class="rank-count">${item.count.toLocaleString()}</span>
          </div>
          <div class="rank-bar"><div class="rank-bar-fill" style="width:${(item.count / max) * 100}%"></div></div>
        </div>
      </div>`
    )
    .join("");
}

/* ---------------------------- source health ---------------------------- */
const SOURCE_DESC = {
  abuseipdb: "Zərərli fəaliyyət bildirilmiş IP ünvanları",
  urlhaus: "Zərərli proqram yayan URL-lər (abuse.ch)",
  threatfox: "C2 server IOC-ları (abuse.ch)",
  otx: "AlienVault icması tərəfindən paylaşılan IOC-lar",
  nvd: "NIST milli zəiflik bazası (CVE)",
  feodo: "Botnet C2 server IP-ləri (abuse.ch Feodo Tracker)",
};
const sourceStatus = {};

async function loadSourceHealth() {
  const [health, sourcesInfo] = await Promise.all([
    fetchJSON("/api/sources/health"),
    fetchJSON("/api/sources"),
  ]);

  const grid = document.getElementById("source-health-grid");
  const detail = document.getElementById("source-cards-detail");
  grid.innerHTML = "";
  detail.innerHTML = "";

  health.items.forEach((item) => {
    sourceStatus[item.source] = item;
    const enabled = sourcesInfo.enabled[item.source];
    let dotClass = "idle";
    if (item.last_status === "success") dotClass = "ok";
    else if (item.last_status === "error") dotClass = "err";
    else if (item.last_status === "skipped") dotClass = "warn";

    const card = document.createElement("div");
    card.className = "health-card";
    card.innerHTML = `
      <div class="health-top">
        <span class="health-name">${item.source}</span>
        <span class="health-dot ${dotClass}"></span>
      </div>
      <div class="health-count">${item.ioc_count.toLocaleString()}</div>
      <div class="health-meta">${relTime(item.last_run)}</div>
    `;
    grid.appendChild(card);

    const dcard = document.createElement("div");
    dcard.className = "source-card";
    dcard.innerHTML = `
      <div class="source-card-top">
        <span class="source-card-name">${item.source}</span>
        <span class="badge-pill ${enabled ? "on" : "off"}">${enabled ? "Aktiv" : "Key yoxdur"}</span>
      </div>
      <div class="source-card-desc">${SOURCE_DESC[item.source] || ""}</div>
      ${item.last_status === "error" || item.last_status === "skipped"
        ? `<div class="source-card-warn ${item.last_status}">${escapeHtml(item.last_message || "")}</div>`
        : ""}
      <div class="source-card-stats">
        <span>${item.ioc_count.toLocaleString()} IOC</span>
        <span>${relTime(item.last_run)}</span>
      </div>
      <button class="btn-secondary refresh-one" data-source="${item.source}">↻ Bu mənbəni yenilə</button>
    `;
    detail.appendChild(dcard);
  });

  detail.querySelectorAll(".refresh-one").forEach((btn) => {
    btn.addEventListener("click", async () => {
      btn.disabled = true;
      btn.textContent = "Yenilənir...";
      await fetchJSON(`/api/refresh/${btn.dataset.source}`, { method: "POST" });
      setTimeout(async () => {
        await refreshDashboard();
        btn.disabled = false;
        btn.textContent = "↻ Bu mənbəni yenilə";
      }, 5000);
    });
  });
}

/* ---------------------------- activity timeline ---------------------------- */
async function loadActivity() {
  const logs = await fetchJSON("/api/fetch-logs?limit=40");
  const el = document.getElementById("activity-timeline");
  if (!logs.items.length) {
    el.innerHTML = `<div style="color:var(--text-mute);">Hələ heç bir fəaliyyət qeydə alınmayıb.</div>`;
    return;
  }
  el.innerHTML = logs.items
    .map((log) => {
      let dotClass = "skipped";
      if (log.status === "success") dotClass = "success";
      else if (log.status === "error") dotClass = "error";
      return `
        <div class="tl-row">
          <div class="tl-dot-wrap"><div class="tl-dot ${dotClass}"></div><div class="tl-line"></div></div>
          <div class="tl-content">
            <div class="tl-top">
              <span class="tl-source">${log.source} · ${log.status}</span>
              <span class="tl-time">${fmtDate(log.started_at)}</span>
            </div>
            <div class="tl-msg">${log.message || ""}</div>
            <div class="tl-stats">${log.fetched_count} çəkildi · ${log.new_count} yeni</div>
          </div>
        </div>`;
    })
    .join("");
}

/* ---------------------------- IOC table ---------------------------- */
async function loadSourcesFilterOptions() {
  const data = await fetchJSON("/api/sources");
  const filterSelect = document.getElementById("filter-source");
  filterSelect.innerHTML = '<option value="">Bütün mənbələr</option>';
  data.sources.forEach((src) => {
    const opt = document.createElement("option");
    opt.value = src;
    opt.textContent = src;
    filterSelect.appendChild(opt);
  });
}

function severityBadge(sev) {
  const s = SEVERITY_ORDER.includes(sev) ? sev : "unknown";
  return `<span class="badge ${s}">${s}</span>`;
}

function typeBadge(t) {
  const color = TYPE_COLORS[t] || "#5b637a";
  return `<span class="type-badge"><span class="type-dot" style="background:${color}"></span>${t}</span>`;
}

async function loadIOCs() {
  const params = new URLSearchParams({ limit: state.limit, offset: state.page * state.limit });
  if (state.filters.source) params.set("source", state.filters.source);
  if (state.filters.ioc_type) params.set("ioc_type", state.filters.ioc_type);
  if (state.filters.severity) params.set("severity", state.filters.severity);
  if (state.filters.q) params.set("q", state.filters.q);

  const data = await fetchJSON(`/api/iocs?${params.toString()}`);
  state.lastIocs = data.items;
  renderIocTable(data);
}

function sortIocs(items) {
  const { field, dir } = state.sort;
  const sorted = [...items].sort((a, b) => {
    let av = a[field], bv = b[field];
    if (typeof av === "string") av = av.toLowerCase();
    if (typeof bv === "string") bv = bv.toLowerCase();
    if (av < bv) return dir === "asc" ? -1 : 1;
    if (av > bv) return dir === "asc" ? 1 : -1;
    return 0;
  });
  return sorted;
}

function renderIocTable(data) {
  const tbody = document.getElementById("ioc-tbody");
  tbody.innerHTML = "";
  const items = sortIocs(data.items);

  if (items.length === 0) {
    const st = state.filters.source && sourceStatus[state.filters.source];
    const reason = st && st.last_status === "error" && st.last_message
      ? `<br><span class="empty-reason">⚠ ${escapeHtml(st.last_message)}</span>`
      : "";
    tbody.innerHTML = `<tr class="empty-row"><td colspan="7">Nəticə tapılmadı.${reason}</td></tr>`;
  } else {
    items.forEach((ioc) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${typeBadge(ioc.ioc_type)}</td>
        <td class="mono">${ioc.value}</td>
        <td>${ioc.source}</td>
        <td>${ioc.threat_type || "-"}</td>
        <td>${severityBadge(ioc.severity)}</td>
        <td>${ioc.confidence?.toFixed(0) ?? "-"}</td>
        <td>${fmtDate(ioc.last_seen)}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  const totalPages = Math.max(1, Math.ceil(data.total / state.limit));
  document.getElementById("page-info").textContent = `Səhifə ${state.page + 1} / ${totalPages} (cəmi ${data.total})`;
  document.getElementById("prev-page").disabled = state.page === 0;
  document.getElementById("next-page").disabled = state.page + 1 >= totalPages;
}

function setupTableSorting() {
  document.querySelectorAll("#ioc-table thead th[data-sort]").forEach((th) => {
    th.addEventListener("click", () => {
      const field = th.dataset.sort;
      if (state.sort.field === field) {
        state.sort.dir = state.sort.dir === "asc" ? "desc" : "asc";
      } else {
        state.sort.field = field;
        state.sort.dir = "asc";
      }
      renderIocTable({ items: state.lastIocs, total: state.lastIocs.length });
    });
  });
}

function exportCsv() {
  if (!state.lastIocs.length) return;
  const cols = ["ioc_type", "value", "source", "threat_type", "severity", "confidence", "country", "last_seen"];
  const rows = [cols.join(",")];
  state.lastIocs.forEach((ioc) => {
    rows.push(cols.map((c) => `"${(ioc[c] ?? "").toString().replace(/"/g, '""')}"`).join(","));
  });
  const blob = new Blob([rows.join("\n")], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "ioc_export.csv";
  a.click();
  URL.revokeObjectURL(url);
}

function setupFilters() {
  document.getElementById("search-input").addEventListener(
    "input",
    debounce((e) => {
      state.filters.q = e.target.value;
      state.page = 0;
      loadIOCs();
    }, 400)
  );
  document.getElementById("topbar-search").addEventListener(
    "input",
    debounce((e) => {
      if (!e.target.value) return;
      document.querySelector('.nav-item[data-view="iocs"]').click();
      document.getElementById("search-input").value = e.target.value;
      state.filters.q = e.target.value;
      state.page = 0;
      loadIOCs();
    }, 500)
  );
  document.getElementById("filter-source").addEventListener("change", (e) => {
    state.filters.source = e.target.value;
    state.page = 0;
    loadIOCs();
  });
  document.getElementById("filter-type").addEventListener("change", (e) => {
    state.filters.ioc_type = e.target.value;
    state.page = 0;
    loadIOCs();
  });
  document.getElementById("filter-severity").addEventListener("change", (e) => {
    state.filters.severity = e.target.value;
    state.page = 0;
    loadIOCs();
  });
  document.getElementById("prev-page").addEventListener("click", () => {
    if (state.page > 0) {
      state.page--;
      loadIOCs();
    }
  });
  document.getElementById("next-page").addEventListener("click", () => {
    state.page++;
    loadIOCs();
  });
  document.getElementById("export-csv-btn").addEventListener("click", exportCsv);
}

function debounce(fn, ms) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

/* ---------------------------- refresh orchestration ---------------------------- */
async function refreshAll() {
  const btn = document.getElementById("refresh-btn");
  btn.disabled = true;
  btn.classList.add("loading");
  try {
    await fetchJSON("/api/refresh", { method: "POST" });
    setTimeout(async () => {
      await refreshDashboard();
      btn.disabled = false;
      btn.classList.remove("loading");
    }, 6000);
  } catch (e) {
    btn.disabled = false;
    btn.classList.remove("loading");
    console.error(e);
  }
}

async function refreshDashboard() {
  await Promise.all([loadStats(), loadSourceHealth(), loadActivity(), loadIOCs()]);
}

/* ---------------------------- AI assistant chat ---------------------------- */
const chatState = { history: [], busy: false };

function chatActivate() {
  const panel = document.getElementById("chat-panel");
  if (panel.classList.contains("is-empty")) {
    panel.classList.remove("is-empty");
    document.getElementById("chat-messages").classList.remove("hidden");
  }
}

function chatAppend(role, text) {
  chatActivate();
  const wrap = document.getElementById("chat-messages");
  const row = document.createElement("div");
  row.className = `chat-msg ${role === "user" ? "user" : "bot"}`;
  row.innerHTML = `
    <div class="chat-avatar">${role === "user" ? "🧑" : "✦"}</div>
    <div class="chat-bubble"></div>
  `;
  row.querySelector(".chat-bubble").textContent = text;
  wrap.appendChild(row);
  wrap.scrollTop = wrap.scrollHeight;
  return row;
}

function chatTyping(show) {
  let el = document.getElementById("chat-typing");
  if (show) {
    if (el) return;
    const wrap = document.getElementById("chat-messages");
    const row = document.createElement("div");
    row.className = "chat-msg bot";
    row.id = "chat-typing";
    row.innerHTML = `<div class="chat-avatar">✦</div><div class="chat-bubble typing-dots"><span></span><span></span><span></span></div>`;
    wrap.appendChild(row);
    wrap.scrollTop = wrap.scrollHeight;
  } else if (el) {
    el.remove();
  }
}

async function sendChatMessage(text) {
  if (!text.trim() || chatState.busy) return;
  chatState.busy = true;
  document.getElementById("chat-send-btn").disabled = true;

  chatAppend("user", text);
  chatState.history.push({ role: "user", text });
  chatTyping(true);

  try {
    const res = await fetchJSON("/api/assistant/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, history: chatState.history }),
    });
    chatTyping(false);
    chatAppend("bot", res.answer);
    chatState.history.push({ role: "model", text: res.answer });
  } catch (e) {
    chatTyping(false);
    chatAppend("bot", "Xəta baş verdi, bir az sonra yenidən cəhd edin.");
    console.error(e);
  } finally {
    chatState.busy = false;
    document.getElementById("chat-send-btn").disabled = false;
  }
}

function setupAssistant() {
  const form = document.getElementById("chat-form");
  const input = document.getElementById("chat-input");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = input.value;
    input.value = "";
    sendChatMessage(text);
  });
  document.querySelectorAll("#chat-suggestions .chip").forEach((chip) => {
    chip.addEventListener("click", () => sendChatMessage(chip.textContent));
  });

  fetchJSON("/api/assistant/status")
    .then((s) => {
      if (!s.enabled) {
        document.getElementById("assistant-status-sub").textContent =
          "AI köməkçi hazırda konfiqurasiya edilməyib (GEMINI_API_KEY yoxdur)";
      }
    })
    .catch(() => {});
}

document.getElementById("refresh-btn").addEventListener("click", refreshAll);
setupNav();
startClock();
setupFilters();
setupTableSorting();
setupAssistant();
loadSourcesFilterOptions();
refreshDashboard();
setInterval(refreshDashboard, 60000);
