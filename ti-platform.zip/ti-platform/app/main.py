"""
Threat Intelligence Aggregation Platform - FastAPI backend.

Bu tətbiq müxtəlif açıq mənbəli Threat Intelligence (TI) API-larından
(AbuseIPDB, URLhaus, ThreatFox, AlienVault OTX, NVD) data toplayır,
normallaşdırıb vahid bazada saxlayır və dashboard-a REST API təqdim edir.
"""
import logging
import threading
from datetime import datetime, timedelta

from fastapi import FastAPI, Depends, Query, BackgroundTasks, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy import func, desc

from app.config import settings
from app.database import init_db, get_db, IOC, FetchLog
from app.aggregator import run_all_collectors, run_single_collector
from app.scheduler import start_scheduler, stop_scheduler
from app.collectors import COLLECTORS
from app.assistant import ask_gemini

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("ti-platform")

app = FastAPI(
    title="Threat Intelligence Aggregation Platform",
    description="Müxtəlif TI mənbələrindən data toplayıb vahid dashboard-da göstərən platforma.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    init_db()
    start_scheduler()
    if settings.FETCH_ON_STARTUP:
        # İlk data çəkilişini arxa planda başlat ki, server dərhal cavab versin
        threading.Thread(target=run_all_collectors, daemon=True).start()


@app.on_event("shutdown")
def on_shutdown():
    stop_scheduler()


# ---------------------------------------------------------------------------
# API endpoint-ləri
# ---------------------------------------------------------------------------

@app.get("/api/health")
def health():
    return {"status": "ok", "time": datetime.utcnow().isoformat()}


@app.get("/api/sources")
def list_sources():
    return {
        "sources": list(COLLECTORS.keys()),
        "enabled": {
            "abuseipdb": settings.ENABLE_ABUSEIPDB and bool(settings.ABUSEIPDB_API_KEY),
            "urlhaus": settings.ENABLE_URLHAUS,
            "threatfox": settings.ENABLE_THREATFOX and bool(settings.THREATFOX_AUTH_KEY),
            "otx": settings.ENABLE_OTX and bool(settings.OTX_API_KEY),
            "nvd": settings.ENABLE_NVD,
            "feodo": True,
        },
    }


@app.get("/api/iocs")
def get_iocs(
    db: Session = Depends(get_db),
    source: str | None = None,
    ioc_type: str | None = None,
    severity: str | None = None,
    q: str | None = Query(None, description="value/description içində axtarış"),
    limit: int = Query(100, le=1000),
    offset: int = 0,
):
    query = db.query(IOC)
    if source:
        query = query.filter(IOC.source == source)
    if ioc_type:
        query = query.filter(IOC.ioc_type == ioc_type)
    if severity:
        query = query.filter(IOC.severity == severity)
    if q:
        like = f"%{q}%"
        query = query.filter((IOC.value.like(like)) | (IOC.description.like(like)))

    total = query.count()
    items = (
        query.order_by(desc(IOC.last_seen))
        .offset(offset)
        .limit(limit)
        .all()
    )
    return {"total": total, "count": len(items), "items": [i.to_dict() for i in items]}


@app.get("/api/iocs/{ioc_id}")
def get_ioc_detail(ioc_id: int, db: Session = Depends(get_db)):
    ioc = db.query(IOC).filter(IOC.id == ioc_id).first()
    if not ioc:
        raise HTTPException(status_code=404, detail="IOC tapılmadı")
    data = ioc.to_dict()
    data["raw_json"] = ioc.raw_json
    return data


@app.get("/api/stats")
def get_stats(db: Session = Depends(get_db)):
    total = db.query(IOC).count()

    by_source = dict(
        db.query(IOC.source, func.count(IOC.id)).group_by(IOC.source).all()
    )
    by_type = dict(
        db.query(IOC.ioc_type, func.count(IOC.id)).group_by(IOC.ioc_type).all()
    )
    by_severity = dict(
        db.query(IOC.severity, func.count(IOC.id)).group_by(IOC.severity).all()
    )

    since_24h = datetime.utcnow() - timedelta(hours=24)
    new_last_24h = db.query(IOC).filter(IOC.created_at >= since_24h).count()

    # son 7 gün üzrə günlük yeni IOC sayı (trend qrafiki üçün)
    since_7d = datetime.utcnow() - timedelta(days=7)
    daily_rows = (
        db.query(func.date(IOC.created_at), func.count(IOC.id))
        .filter(IOC.created_at >= since_7d)
        .group_by(func.date(IOC.created_at))
        .all()
    )
    daily_trend = [{"date": str(d), "count": c} for d, c in daily_rows]

    top_threat_types = (
        db.query(IOC.threat_type, func.count(IOC.id).label("cnt"))
        .group_by(IOC.threat_type)
        .order_by(desc("cnt"))
        .limit(10)
        .all()
    )

    top_countries = (
        db.query(IOC.country, func.count(IOC.id).label("cnt"))
        .filter(IOC.country.isnot(None), IOC.country != "")
        .group_by(IOC.country)
        .order_by(desc("cnt"))
        .limit(8)
        .all()
    )

    avg_confidence = db.query(func.avg(IOC.confidence)).scalar() or 0

    since_prev_24h = datetime.utcnow() - timedelta(hours=48)
    prev_24h_count = (
        db.query(IOC)
        .filter(IOC.created_at >= since_prev_24h, IOC.created_at < since_24h)
        .count()
    )
    if prev_24h_count > 0:
        trend_pct = round(((new_last_24h - prev_24h_count) / prev_24h_count) * 100, 1)
    else:
        trend_pct = 100.0 if new_last_24h > 0 else 0.0

    return {
        "total": total,
        "new_last_24h": new_last_24h,
        "trend_pct": trend_pct,
        "avg_confidence": round(avg_confidence, 1),
        "by_source": by_source,
        "by_type": by_type,
        "by_severity": by_severity,
        "daily_trend": daily_trend,
        "top_threat_types": [{"name": t or "unknown", "count": c} for t, c in top_threat_types],
        "top_countries": [{"code": c, "count": n} for c, n in top_countries],
    }


@app.get("/api/sources/health")
def sources_health(db: Session = Depends(get_db)):
    """Hər mənbə üçün son sinxronizasiya statusu (sistem statusu paneli üçün)."""
    result = []
    for source in COLLECTORS.keys():
        last_log = (
            db.query(FetchLog)
            .filter(FetchLog.source == source)
            .order_by(desc(FetchLog.started_at))
            .first()
        )
        ioc_count = db.query(IOC).filter(IOC.source == source).count()
        result.append({
            "source": source,
            "ioc_count": ioc_count,
            "last_status": last_log.status if last_log else "never",
            "last_run": last_log.started_at.isoformat() if last_log else None,
            "last_message": last_log.message if last_log else "",
        })
    return {"items": result}


@app.get("/api/fetch-logs")
def get_fetch_logs(db: Session = Depends(get_db), limit: int = 30):
    logs = db.query(FetchLog).order_by(desc(FetchLog.started_at)).limit(limit).all()
    return {"items": [l.to_dict() for l in logs]}


@app.post("/api/refresh")
def refresh_all(background_tasks: BackgroundTasks):
    background_tasks.add_task(run_all_collectors)
    return {"status": "started", "message": "Bütün mənbələrdən data çəkilməsi arxa planda başladıldı"}


@app.post("/api/refresh/{source}")
def refresh_source(source: str, background_tasks: BackgroundTasks):
    if source not in COLLECTORS:
        raise HTTPException(status_code=404, detail=f"Naməlum mənbə: {source}")
    background_tasks.add_task(run_single_collector, source)
    return {"status": "started", "message": f"{source} mənbəsindən data çəkilməsi arxa planda başladıldı"}


class ChatMessage(BaseModel):
    role: str
    text: str


class ChatRequest(BaseModel):
    message: str
    history: list[ChatMessage] = []


@app.post("/api/assistant/chat")
def assistant_chat(payload: ChatRequest, db: Session = Depends(get_db)):
    if not payload.message or not payload.message.strip():
        raise HTTPException(status_code=400, detail="Mesaj boş ola bilməz")
    history = [h.model_dump() for h in payload.history]
    answer = ask_gemini(db, payload.message.strip(), history)
    return {"answer": answer}


@app.get("/api/assistant/status")
def assistant_status():
    return {"enabled": bool(settings.GEMINI_API_KEY)}


# ---------------------------------------------------------------------------
# Statik dashboard (frontend)
# ---------------------------------------------------------------------------
app.mount("/static", StaticFiles(directory="app/static"), name="static")


@app.get("/")
def dashboard():
    return FileResponse("app/static/index.html")
