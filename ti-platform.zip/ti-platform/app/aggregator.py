"""
Bütün mənbələrdən datanı çəkib bazaya yazan orkestrator.
Həm scheduler, həm də manual "refresh" endpoint-i bunu çağırır.
"""
import logging
from datetime import datetime

from app.database import SessionLocal, FetchLog
from app.collectors import COLLECTORS

logger = logging.getLogger("ti-platform.aggregator")


def run_all_collectors() -> list[dict]:
    results = []
    for source, fetch_fn in COLLECTORS.items():
        db = SessionLocal()
        log_entry = FetchLog(source=source, status="running", started_at=datetime.utcnow())
        db.add(log_entry)
        db.commit()
        db.refresh(log_entry)

        try:
            result = fetch_fn(db)
        except Exception as e:
            logger.exception("Collector %s xəta ilə dayandı", source)
            result = {"status": "error", "message": str(e), "fetched": 0, "new": 0}

        log_entry.status = result["status"]
        log_entry.message = result["message"]
        log_entry.fetched_count = result["fetched"]
        log_entry.new_count = result["new"]
        log_entry.finished_at = datetime.utcnow()
        db.commit()
        db.close()

        result["source"] = source
        results.append(result)
        logger.info("[%s] status=%s fetched=%s new=%s", source, result["status"], result["fetched"], result["new"])

    return results


def run_single_collector(source: str) -> dict:
    if source not in COLLECTORS:
        return {"status": "error", "message": f"Naməlum mənbə: {source}", "fetched": 0, "new": 0, "source": source}

    db = SessionLocal()
    log_entry = FetchLog(source=source, status="running", started_at=datetime.utcnow())
    db.add(log_entry)
    db.commit()
    db.refresh(log_entry)

    try:
        result = COLLECTORS[source](db)
    except Exception as e:
        logger.exception("Collector %s xəta ilə dayandı", source)
        result = {"status": "error", "message": str(e), "fetched": 0, "new": 0}

    log_entry.status = result["status"]
    log_entry.message = result["message"]
    log_entry.fetched_count = result["fetched"]
    log_entry.new_count = result["new"]
    log_entry.finished_at = datetime.utcnow()
    db.commit()
    db.close()

    result["source"] = source
    return result
