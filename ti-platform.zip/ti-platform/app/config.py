"""
Konfiqurasiya modulu.
Bütün API açarları və tənzimləmələr .env faylından oxunur.
"""
import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    BASE_DIR = Path(__file__).resolve().parent.parent
    load_dotenv(BASE_DIR / ".env")
except ImportError:
    pass


def _get_bool(name: str, default: bool = False) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in ("1", "true", "yes", "on")


class Settings:
    # --- API açarları (boş olarsa həmin mənbə avtomatik atlanılır) ---
    ABUSEIPDB_API_KEY: str = os.getenv("ABUSEIPDB_API_KEY", "")
    OTX_API_KEY: str = os.getenv("OTX_API_KEY", "")
    VIRUSTOTAL_API_KEY: str = os.getenv("VIRUSTOTAL_API_KEY", "")
    URLHAUS_AUTH_KEY: str = os.getenv("URLHAUS_AUTH_KEY", "")
    THREATFOX_AUTH_KEY: str = os.getenv("THREATFOX_AUTH_KEY", "")
    NVD_API_KEY: str = os.getenv("NVD_API_KEY", "")

    # --- Verilənlər bazası ---
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./data/threat_intel.db")

    # --- Scheduler (dəqiqə ilə) ---
    FETCH_INTERVAL_MINUTES: int = int(os.getenv("FETCH_INTERVAL_MINUTES", "60"))
    FETCH_ON_STARTUP: bool = _get_bool("FETCH_ON_STARTUP", True)

    # --- Mənbələrin aktiv/deaktiv edilməsi ---
    ENABLE_ABUSEIPDB: bool = _get_bool("ENABLE_ABUSEIPDB", True)
    ENABLE_URLHAUS: bool = _get_bool("ENABLE_URLHAUS", True)
    ENABLE_THREATFOX: bool = _get_bool("ENABLE_THREATFOX", True)
    ENABLE_OTX: bool = _get_bool("ENABLE_OTX", False)
    ENABLE_NVD: bool = _get_bool("ENABLE_NVD", True)

    # --- Server ---
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "8000"))

    # --- Hər mənbədən neçə qeyd çəkilsin (limit) ---
    ABUSEIPDB_LIMIT: int = int(os.getenv("ABUSEIPDB_LIMIT", "500"))
    URLHAUS_LIMIT: int = int(os.getenv("URLHAUS_LIMIT", "500"))
    THREATFOX_LIMIT: int = int(os.getenv("THREATFOX_LIMIT", "500"))


settings = Settings()
