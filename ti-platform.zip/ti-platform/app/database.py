"""
Verilənlər bazası qurulumu (SQLAlchemy).
"""
import os
from datetime import datetime

from sqlalchemy import (
    create_engine, Column, Integer, String, DateTime, Text, Float, UniqueConstraint
)
from sqlalchemy.orm import declarative_base, sessionmaker

from app.config import settings

# data qovluğunu yarat (sqlite fayl üçün)
if settings.DATABASE_URL.startswith("sqlite"):
    db_path = settings.DATABASE_URL.split("///")[-1]
    os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)

engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False} if settings.DATABASE_URL.startswith("sqlite") else {},
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class IOC(Base):
    """
    Normallaşdırılmış Indicator of Compromise (IOC) qeydi.
    Bütün mənbələrdən gələn data bu vahid formata çevrilir.
    """
    __tablename__ = "iocs"
    __table_args__ = (
        UniqueConstraint("ioc_type", "value", "source", name="uq_ioc_type_value_source"),
    )

    id = Column(Integer, primary_key=True, index=True)
    ioc_type = Column(String(32), index=True)       # ip, url, domain, hash, cve
    value = Column(String(1024), index=True)        # IOC-un özü (IP, URL, hash, CVE-ID)
    source = Column(String(64), index=True)         # abuseipdb, urlhaus, threatfox, otx, nvd
    threat_type = Column(String(128), index=True)   # malware, phishing, botnet, cve, ...
    confidence = Column(Float, default=0.0)         # 0-100 arası güvən balı
    severity = Column(String(16), default="unknown")  # low, medium, high, critical
    tags = Column(Text, default="")                 # vergüllə ayrılmış teqlər
    country = Column(String(8), default="")
    description = Column(Text, default="")
    raw_json = Column(Text, default="")              # orijinal API cavabı (audit üçün)
    first_seen = Column(DateTime, default=datetime.utcnow)
    last_seen = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "ioc_type": self.ioc_type,
            "value": self.value,
            "source": self.source,
            "threat_type": self.threat_type,
            "confidence": self.confidence,
            "severity": self.severity,
            "tags": self.tags,
            "country": self.country,
            "description": self.description,
            "first_seen": self.first_seen.isoformat() if self.first_seen else None,
            "last_seen": self.last_seen.isoformat() if self.last_seen else None,
        }


class FetchLog(Base):
    """Hər collector işə düşəndə nəticəni qeyd edir (dashboard-da göstərmək üçün)."""
    __tablename__ = "fetch_logs"

    id = Column(Integer, primary_key=True, index=True)
    source = Column(String(64), index=True)
    status = Column(String(16))       # success, error, skipped
    message = Column(Text, default="")
    fetched_count = Column(Integer, default=0)
    new_count = Column(Integer, default=0)
    started_at = Column(DateTime, default=datetime.utcnow)
    finished_at = Column(DateTime, nullable=True)

    def to_dict(self):
        return {
            "id": self.id,
            "source": self.source,
            "status": self.status,
            "message": self.message,
            "fetched_count": self.fetched_count,
            "new_count": self.new_count,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
        }


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
